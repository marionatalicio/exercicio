<html>
<footer>
    <p>endereco</p>

</footer>
</body>
</html>