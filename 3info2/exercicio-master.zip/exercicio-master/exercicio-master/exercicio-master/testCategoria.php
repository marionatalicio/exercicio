<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 01/03/18
 * Time: 16:19
 */
require_once "Categoria.php";
$p1 = new Categoria(1,"esporte", "produtos de esporte");
var_dump($p1);