<!-- visoes/categoria/index-->
<html>
<head>

</head>
<body>
<h2>Detalhes da categoria - <?= $categoria->getNome()?></h2>
<p><?= $categoria->getDescricao()?></p>


